import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'typography-component',
  templateUrl: './typography.component.html',
  styleUrls: ['./typography.component.css']
})
export class TypographyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
