import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'buttons-component',
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.css']
})
export class ButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
